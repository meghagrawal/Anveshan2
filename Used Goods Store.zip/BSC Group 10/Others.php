<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Other Categories</title>
</head>

<body>

<h1 align="center"><font face="Snap ITC" color="#371F98">Others</font></h1>
<table width="100%" border="1">
        <tr> 
          <td><strong><font color="#000000">ID</font></strong></td>
          <td><strong><font color="#000000">Caption</font></strong></td>
          <td><strong><font color="#000000">Image</font></strong></td>
          <td><strong><font color="#000000">Price</font></strong></td>
		  <td width="236"><strong><font color="#000000">Address</font></strong></td>
         
        </tr>
		<?php
    
$servername = "localhost";
$username = "root";
$password = "";
$dbname="UGS";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

    $sql = "SELECT * FROM AD where category='Others'";
    $result = mysqli_query($conn,$sql);
    while($row=mysqli_fetch_array($result))
    {
    ?>
        <tr> 
          <td><?php echo $row['ID']; ?></td>
          <td><?php echo $row['Caption']; ?></td>
          <td width="250px"><?php echo '<img data-u="image" src=" data/'.$row['Image'].'" width="100%" />'; ?></td>
          <td><?php echo $row['Price']; ?></td>
          <td><?php echo $row['Address'];?></td>
        </tr>
  <?php
  }
  mysqli_close($conn);
  ?>
		<p>&nbsp;</p>
</table>
</body>

</html>