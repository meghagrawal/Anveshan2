<?php
session_start()
?><html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>MY ADS</title>
</head>

<body>

<table border="1" width="100%" height="467">
	<tr>
		<td width="81%" height="93">
		<p align="center"><font face="Snap ITC" size="6" color="#371F98">MY ADS</font></p>
	  </td>
		<td rowspan="2" width="19%">
		<p align="center"><font face="Snap ITC" color="#371F98" size="5">MENU</font></p>
		<p align="left"><b><font face="Comic Sans MS" color="#371F98" size="4">&nbsp;<a href="User.php" style="text-decoration: none"><font color="#371F98">MY 
		ADS</font></a></font></b></p>
		<p align="left"><b><font face="Comic Sans MS" color="#371F98" size="4">&nbsp;<a target="main" href="Sell%20Here.htm" style="text-decoration: none"><font color="#371F98">SELL</font></a></font></b></p>
		<p align="left"><b><font face="Comic Sans MS" color="#371F98" size="4">&nbsp;<a href="data/Logout.php" style="text-decoration: none"><font color="#371F98">LOGOUT</font></a></font></b></p>
		<p align="left">&nbsp;</p>
		<p align="left">&nbsp;</p>
	  <p align="center"></td>
	</tr>
	<tr>
		<td><?php include 'data/DUser.php';?>
		<table width="100%" border="1">
        <tr> 
          <td><strong><font color="#000000">ID</font></strong></td>
          <td><strong><font color="#000000">Caption</font></strong></td>
          <td><strong><font color="#000000">Image</font></strong></td>
          <td><strong><font color="#000000">Price</font></strong></td>
          <td><strong><font color="#000000">Category</font></strong></td>
         
        </tr>
		<?php
		session_start();
$servername = "localhost";
$user = "root";
$password = "";
$dbname="UGS";

// Create connection
$conn = new mysqli($servername, $user, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
	$usern=$_SESSION['username'];
    $sql = "SELECT * FROM AD where Username= '$usern' ";
    $result = mysqli_query($conn,$sql);
    while($row=mysqli_fetch_array($result))
    {
    ?>
        <tr> 
          <td><?php echo $row['ID']; ?></td>
          <td><?php echo $row['Caption']; ?></td>
          <td width="250px"><?php echo '<img data-u="image" src=" data/'.$row['Image'].'" width="100%" />'; ?></td>
          <td><?php echo $row['Price']; ?></td>
          <td><?php echo $row['Category']; ?></td>
         
        </tr>
  <?php
  }
  mysqli_close($conn);
  ?>
		<p>&nbsp;</p>
</table>

</body>

</html>
