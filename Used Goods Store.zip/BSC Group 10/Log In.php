<?php include 'data/Check.php';?><html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Login</title>
<base target="main">
</head>

<body Style="margin-top: 0px; margin-right: 10px; margin-bottom: 0px; margin-left: 0px;">

 <form name="Login" action="data/Login.php" method="POST">

<p bordercolor="#FFFFFF" align="center" style="font-weight: 700; background-color: #ffcccc; border-radius: 5px;  box-shadow: 0px 1px 1px grey;">
<font size="5" face="Snap ITC" color="#371F98">LOG IN</font></p>


<table border="0" width="100%" cellpadding="2" cellspacing="20">
	<tr>
		<td width="19%" bordercolor="#FFFFFF" bgcolor="#ffcccc" style=" border-radius: 5px;  box-shadow: 0px 1px 1px grey;">
		<p align="center"><font color="#371F98">&nbsp;<b><font face="Comic Sans MS">USERNAME</font></b></font></td>
		<td width="81%">&nbsp;
		<input type="text" name="name"  id="name" size="20" placeholder="Enter Username" required="required" style=" border-radius: 5px;  box-shadow: 0px 1px 1px grey;" /></td>
		
	</tr>
	<tr>
		<td bordercolor="#FFFFFF" bgcolor="#ffcccc" style=" border-radius: 5px;  box-shadow: 0px 1px 1px grey;">
		<p align="center"><b><font color="#371F98" face="Comic Sans MS">&nbsp;PASSWORD</font></b></td>
		<td width="81%">&nbsp; 
		<input type="password" name="pass" id="pass" size="20" placeholder="Enter Password" required="required" style=" border-radius: 5px;  box-shadow: 0px 1px 1px grey;"/></td>
	</tr>
		<tr>
		<td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
		<input type="submit" value="Login" name="B1"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="Comic Sans MS">
	<a href="Password%20Retrieval.htm">
     Forgot Password?</a>&nbsp;</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="Comic Sans MS"><a href="Sign%20Up.html">New 
		User?</a>&nbsp;</font>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 
		</td>
	</tr>
</table>
</form>
   
    </div>

    <p>&nbsp;</p>

    </body>

</html>