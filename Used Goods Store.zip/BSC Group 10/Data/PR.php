<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="UGS";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$cemail=$_POST['email'];
$cmobile=$_POST['mobile'];

$sql="select Email, Mobile, Password from REGISTER_DATA where email='".$cemail."' and mobile='".$cmobile."'";
$result= mysqli_query($conn, $sql);

if (mysqli_num_rows($result) >=0) {
    while($row = mysqli_fetch_assoc($result)) {
        echo "<p align=\"center\">"."<font face=\"Comic Sans MS\" size=\"5\" color=\"371F98\">"."<br>Here's Your Password:"."<br><br>Email: " . $row['Email']."<br><br>". "Mobile: " . $row['Mobile']. "<br><br>Password: " . $row['Password'];
    }
} 
else {
    echo "0 results";
}

mysqli_close($conn);

?>