<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="UGS";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$cuser=$_POST['name'];
$cpass=$_POST['pass'];

$sql="select Name from REGISTER_DATA where username='".$cuser."' and password='".$cpass."'";
$result= mysqli_query($conn, $sql);

if (mysqli_num_rows($result) >=0) {
    while($row = mysqli_fetch_assoc($result)) {
	session_start();
    $_SESSION['loggedin'] = true;
    $_SESSION['username'] = $cuser;
	header('Location: ../User.php');
    }
} 
else { echo "0 Results";
}

mysqli_close($conn);
?>

