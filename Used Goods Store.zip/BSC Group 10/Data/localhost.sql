-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 30, 2017 at 04:03 AM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `ugs`
-- 
CREATE DATABASE `ugs` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ugs`;

-- --------------------------------------------------------

-- 
-- Table structure for table `ad`
-- 

CREATE TABLE `ad` (
  `Category` varchar(30) NOT NULL,
  `Caption` text NOT NULL,
  `Image` varchar(500) NOT NULL,
  `Price` float NOT NULL,
  `Address` text NOT NULL,
  `ID` int(5) NOT NULL auto_increment,
  `Username` varchar(100) NOT NULL,
  PRIMARY KEY  (`Image`,`ID`),
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `Image` (`Image`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

-- 
-- Dumping data for table `ad`
-- 

INSERT INTO `ad` (`Category`, `Caption`, `Image`, `Price`, `Address`, `ID`, `Username`) VALUES 
('Bicycle', 'BIKE IT RIDE IT!', 'Uploads/bi1.png', 1500, 'SHRI SHANTA VIHAR', 29, 'DIKSHA'),
('Bicycle', 'LADY BIRD', 'Uploads/bi3.png', 1000, 'SHRI SHANTA VIHAR', 22, 'neha'),
('Books', 'LET''S STUDY!', 'Uploads/c6.png', 500, 'SHRI SHANTA NIKAI', 31, 'AKA'),
('Fan', 'GARMI ME THANDI KA EHSAAS!!', 'Uploads/f3.png', 900, 'SHRI SHANTA NIKAI', 30, 'AKA'),
('Fan', 'chill yourself with this orient fan!!', 'Uploads/f6.png', 900, 'shri shanta tirtham', 24, 'FALU'),
('Notes', 'STUDY STUFF HERE!', 'Uploads/n1.png', 150, 'SHRI SHANTA VIHAR', 28, 'DIKSHA'),
('Notes', 'properly arranged notes with spriral binding', 'Uploads/n6.png', 100, 'shri shanta vasti', 20, 'neha'),
('Books', 'General knowledge', 'Uploads/o2.png', 150, 'shri shanta bhuwnam', 18, 'Hema'),
('Others', 'BUY IT AT AFFORDABLE PRICES', 'Uploads/ot2.png', 500, 'SHRI SHANTA BHUWNAM', 26, 'tani'),
('Others', 'sale sale sale!!!', 'Uploads/ot3.png', 500, 'shri shanta geham', 25, 'hema'),
('Books', 'GEOGRAPHIC WORLD', 'Uploads/ss6.png', 350, 'SHRI SHANTA VASTI', 27, 'tani'),
('Books', 'EXPLORE MORE!', 'Uploads/ss8.png', 250, 'SHRI SHANTA VIHAR', 33, 'ANJI'),
('Study Table', 'COMFORT URSELF AND THEN STUDY!', 'Uploads/st2.png', 250, 'SHRI SHANTA BHUWNAM', 34, 'HEMA'),
('Study Table', 'Why wandering here and there?! buy your own study table.', 'Uploads/st3.png', 250, 'shri shanta nikunj', 23, 'FALU'),
('Study Table', 'STUDY STUDY STUDY!!!!', 'Uploads/st5.png', 300, 'SHRI SHANTA NIKAI', 35, 'HEMA'),
('Trunks', 'three months used truck at affordable price', 'Uploads/tr1.png', 400, 'shri shanta bhawnam', 21, 'neha'),
('Trunks', 'Trunk in working condition at affordable price', 'Uploads/tr3.png', 350, 'shri shanta vihar', 19, 'falu'),
('Trunks', 'LOCK IT HERE!', 'Uploads/tr5.png', 500, 'SHRI SHANTA VIHAR', 32, 'ANJI');

-- --------------------------------------------------------

-- 
-- Table structure for table `register_data`
-- 

CREATE TABLE `register_data` (
  `Name` varchar(200) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Email` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL default 'userid@gmail.com',
  `Username` varchar(100) NOT NULL,
  `Password` varchar(200) NOT NULL,
  PRIMARY KEY  (`Mobile`,`Username`),
  UNIQUE KEY `Mobile` (`Mobile`),
  UNIQUE KEY `Username` (`Username`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `register_data`
-- 

INSERT INTO `register_data` (`Name`, `Mobile`, `Email`, `Username`, `Password`) VALUES 
('Himanshi Agarwal', '1259463214', 'divyankaraj142@gmail.com', 'Hema', 'hema'),
('tanisha', '4254657454', 'tanisha1@gmail.com', 'tani', 'tani'),
('DIKSHA SAINI', '4524758732', 'SAINIJI2@GMAIL.COM', 'DIKSHA', 'DIKSHA'),
('ANJALI CHAUHAN', '54588/5875', 'CHAUHAN9457@GMAIL.COM', 'ANJI', 'ANJI'),
('shalini raghuvanshi', '5946531633', 'shaliniontop10@gmail.com', 'falu', 'falu'),
('neha agarwal', '9421454514', '511agarwalneha@gmail.com', 'neha', 'neha'),
('Megha Agrawal', '9458229557', 'agrawalmegha360@gmail.com', 'megha', 'bbuunn'),
('AKANSHA NIRANJAN', '9864746463', 'AKA6@GMAIL.COM', 'AKA', 'AKA');
