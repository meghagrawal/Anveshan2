<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="ugs";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 

$cname=$_POST['name'];
$cemail=$_POST['email'];
$cmobile=$_POST['mobile'];
$cuser=$_POST['user'];
$cpass=$_POST['pass'];
$link_address="../log in.php";
$sql="insert into REGISTER_DATA(name, mobile, email, username, password) values('$cname','$cmobile', '$cemail', '$cuser', '$cpass')";
if(mysqli_query($conn, $sql))
{
}
else
{
die("Failed:".mysqli_error($conn));

}
$conn->close();
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
$i=1;
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 
$sql="select * from REGISTER_DATA";
$result=$conn->query($sql);
if($result->num-rows>=0)
{
//output data
while($row=$result->fetch_assoc())
{
while(($row["Username"]==$cuser)&& ($i==1))
{
echo "<p align=\"center\">"."<font size=5 color=\"#371f98\" face=\"Snap ITC\"> <br>REGISTRATION SUCCESSFUL</font>"."<font size=4 color=\"#371f98\" face=\"Comic sans MS\"> "."<br><br><br>"."Name:	".$row["Name"]."<br>"."Mobile:	".$row["Mobile"]."<br>"."Email:	".$row["Email"]."<br>"."Username:	".$row["Username"]."<br>"."Password:	".$row["Password"]."<br>"."</font>"."</p";
echo "<br><br><font size=5 color=\"#371f98\" face=\"Comic Sans MS\">"."<a href='".$link_address."'><b>Login here</b></a>"."</font>";
$i=2;
}
}
}
else
{
echo "0 results";
}
$conn->close();
?>