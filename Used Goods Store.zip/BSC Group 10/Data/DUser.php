<?php 
session_start();
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    echo "<font color=\"#371F98\" face=\"Comic Sans MS\" size=\"4\">"."Welcome " . $_SESSION['username'] . "!"."</font>";
} else {
    echo "Please log in first to see this page.";
} ?>