vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Mar 2017 04:08:48 -0000
vti_extenderversion:SR|6.0.2.6551
vti_author:SR|BHUWNAM54\\admin
vti_modifiedby:SR|BHUWNAM54\\admin
vti_timecreated:TR|24 Mar 2017 10:42:06 -0000
vti_title:SR|MY ADS
vti_backlinkinfo:VX|Sell\\ Here.htm User.php
vti_nexttolasttimemodified:TW|29 Mar 2017 19:23:34 -0000
vti_cacheddtm:TX|29 Mar 2017 19:23:34 -0000
vti_filesize:IR|2622
vti_cachedtitle:SR|MY ADS
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|User.php H|Sell\\ Here.htm H|data/Logout.php
vti_cachedsvcrellinks:VX|FHUS|User.php FHUS|Sell\\ Here.htm FHUS|data/Logout.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_language:SR|en-us
