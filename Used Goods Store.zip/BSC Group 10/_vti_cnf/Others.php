vti_encoding:SR|utf8-nl
vti_author:SR|BHUWNAM54\\admin
vti_modifiedby:SR|BHUWNAM54\\admin
vti_timelastmodified:TR|30 Mar 2017 03:58:36 -0000
vti_timecreated:TR|29 Mar 2017 19:40:03 -0000
vti_title:SR|Other Categories
vti_extenderversion:SR|6.0.2.6551
vti_backlinkinfo:VX|search.html
vti_cacheddtm:TX|30 Mar 2017 03:58:36 -0000
vti_filesize:IR|1608
vti_cachedtitle:SR|Other Categories
vti_cachedbodystyle:SR|<body>
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_language:SR|en-us
