vti_encoding:SR|utf8-nl
vti_author:SR|BHUWNAM54\\admin
vti_modifiedby:SR|BHUWNAM54\\admin
vti_timelastmodified:TR|01 Apr 2017 04:27:44 -0000
vti_timecreated:TR|24 Mar 2017 10:16:07 -0000
vti_title:SR|Login
vti_extenderversion:SR|6.0.2.6551
vti_backlinkinfo:VX|Sell\\ Here.htm banner.html
vti_nexttolasttimemodified:TW|24 Mar 2017 11:19:02 -0000
vti_cacheddtm:TX|01 Apr 2017 04:27:46 -0000
vti_filesize:IR|2513
vti_cachedtitle:SR|Login
vti_cachedbodystyle:SR|<body Style="margin-top: 0px; margin-right: 10px; margin-bottom: 0px; margin-left: 0px;">
vti_cachedlinkinfo:VX|A|data/Login.php H|Password\\ Retrieval.htm H|Sign\\ Up.html
vti_cachedsvcrellinks:VX|FAUS|data/Login.php FHUS|Password\\ Retrieval.htm FHUS|Sign\\ Up.html
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_language:SR|en-us
